<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Library</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Custom Navbar Styles */
        .navbar {
            background-color: rgba(0,64,128,1); /* Navbar background color */
            color: #fff; /* Navbar text color */
            padding: 10px 20px; /* Navbar padding */
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            color: #fff; /* Brand name color */
            text-decoration: none; /* Remove underline */
        }
        .navbar-brand:hover {
            color: #f0f0f0; /* Brand name color on hover */
        }
        .navbar-toggler {
            color: #fff; /* Toggler icon color */
            border: none; /* Remove border */
        }
        .navbar-toggler:focus {
            outline: none; /* Remove focus outline */
        }
        .navbar-toggler:hover {
            background-color: rgba(255, 255, 255, 0.1); /* Background color on hover */
        }
        .navbar-nav {
            display: flex;
            align-items: center;
            justify-content: center; /* Center align navbar items */
            gap: 20px; /* Spacing between navbar items */
            list-style: none; /* Remove list-style */
            padding: 0; /* Remove default padding */
        }
        .nav-item {
            position: relative;
        }
        .nav-link {
            font-size: 1.1rem;
            color: #fff; /* Link color */
            text-decoration: none; /* Remove underline */
            padding: 0.5rem 1rem;
            border-radius: 5px; /* Rounded corners for links */
        }
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1); /* Background color on hover */
        }
        .dropdown-menu {
            background-color: rgb(10, 70,100); /* Dropdown menu background color */
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            float: left;
            min-width: 10rem;
            padding: 0.5rem 0;
            margin: 0.120rem 0 0;
            margin-top:1.5rem;
            font-size: 1rem;
            color: #212529;
            text-align: left;
            list-style: none;
            border-radius: 0.25rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .dropdown-menu.show {
            display: block;
        }
        .dropdown-item {
            color: #333; /* Dropdown item text color */
            text-decoration: none; /* Remove underline */
            display: block;
            padding: 0.25rem 1.5rem;
            clear: both;
            font-weight: 400;
            color: white;
            text-align: inherit;
            white-space: nowrap;
            background-color: transparent;
            border: 0;
        }
        .dropdown-item:hover {
            background-color: rgb(77, 130, 156); /* Dropdown item background color on hover */
        }
        .jumbotron {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
            margin-top: 70px; /* Adjust margin-top to fit navbar height */
        }
        .slide-box {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            z-index: 1;
        }
        .jumbotron img {
            width: 100%; /* Full width */
            height: 100%; /* Set the height */
            object-fit: cover;
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }
        

        .mySlides.fade {
            opacity: 1;
        }

        @keyframes fadeInOut {
            0% {
                opacity: 0;
            }
            25% {
                opacity: 1;
            }
            75% {
                opacity: 1;
            }
            100% {
                opacity: 0;
            }
        }

        .mySlides.fade {
            animation: fade 15s infinite;
        }

 /* Custom CSS for Features Section */
.features {
    background-color: #f8f9fa;
    padding: 50px 0;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px; /* Add some space between items */
}

.feature {
    text-align: center;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    width: 300px; /* Adjusted width for each feature */
    transition: transform 0.3s; /* Keep the same transition */
    margin: 10px;
    background-color: #fff; /* White background */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Soft shadow */
}

.feature:hover {
    transform: scale(1.05); /* Keep the same hover effect */
}

.feature img {
    width: 100%;
    height: 200px;
    /* border-top-left-radius: 10px;
    border-top-right-radius: 10px; */
    object-fit: cover;
}

.feature-content {
    padding: 20px;
}

.feature-title {
    font-weight: bold;
    margin-bottom: 10px;
    color: #333; /* Darker text color */
}

.feature-text {
    color: #666; /* Slightly darker text color */
    margin-bottom: 20px;
}

/* Center align text */
.feature-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

    /* Gallery Section Styles */
    .gallery {
        padding: 50px 0;
        background-color: #f0f0f0;
        text-align: center;
    }

    .gallery img {
        width: 200px;
        height: 200px;
        object-fit: cover;
        border-radius: 10px;
        margin: 10px;
        position: relative;
        transition: transform 0.3s ease;
    }

    .gallery img:hover {
        transform: scale(1.05);
    }

    .gallery .gallery-caption {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 10px;
        border-radius: 5px;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .gallery img:hover .gallery-caption {
        opacity: 1;
    }

    /* Footer Styles */
    .footer {
        background-color: #333;
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    .footer i {
        font-size: 24px;
        margin: 0 10px;
    }
        
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-sm navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Hospital</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" role="button" data-bs-toggle="dropdown">
                            About
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="aboutDropdown">
                            <li><a class="dropdown-item" href="services.html">Services</a></li>
                            <li><a class="dropdown-item" href="doctors.html">Doctors</a></li>
                            <li><a class="dropdown-item" href="appointment.html">Appointment</a></li>
                            <li><a class="dropdown-item" href="review.html">Review</a></li>
                            <li><a class="dropdown-item" href="gallery.html">Gallery</a></li>
                            <li><a class="dropdown-item" href="patient.html">Patient</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Slideshow Section -->
    <div class="jumbotron">
        <div class="mySlides fade">
            <img src="image/b.jpg" alt="Slide 1">
        </div>
        <div class="mySlides fade">
            <img src="image/ha.jpg" alt="Slide 2">
        </div>
        <div class="mySlides fade">
            <img src= "image/b1.jpg" alt="Slide 3">
        </div>
        <div class="mySlides fade">
            <img src="image/b3.jpg" alt="Slide 4">
        </div>
        <div class="slide-box">
            <h1>Welcome to the Hospital</h1>
            <p>Where patient care meets excellence.</p>
            <a href="#" class="btn btn-primary">Book Appointment</a>
        </div>
    </div>

    <!-- Features Section -->
    <section class="features">
        <div class="feature">
            <img src="feature-1.jpg" alt="Feature 1">
            <div class="feature-content">
                <h3 class="feature-title">Emergency Services</h3>
                <p class="feature-text">Our emergency department is open 24/7 to handle any medical emergencies.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-2.jpg" alt="Feature 2">
            <div class="feature-content">
                <h3 class="feature-title">Expert Doctors</h3>
                <p class="feature-text">Meet our team of experienced and caring doctors who are dedicated to your health.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="image/b.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
        <div class="feature">
            <img src="feature-3.jpg" alt="Feature 3">
            <div class="feature-content">
                <h3 class="feature-title">Advanced Technology</h3>
                <p class="feature-text">We use cutting-edge technology to provide accurate diagnosis and treatment.</p>
                <a href="#" class="btn btn-outline-primary">Read More</a>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="gallery">
        <h2>Our Gallery</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="gallery-item">
                    <img src="image/b.jpg" alt="Gallery Image 1">
                    <div class="gallery-caption">Image 1</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="gallery-item">
                    <img src="image/b1.jpg" alt="Gallery Image 2">
                    <div class="gallery-caption">Image 2</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="gallery-item">
                    <img src="image/b2.jpg" alt="Gallery Image 3">
                    <div class="gallery-caption">Image 3</div>
                </div>
                <div class="col-md-4">
                <div class="gallery-item">
                    <img src="image/b2.jpg" alt="Gallery Image 3">
                    <div class="gallery-caption">Image 3</div>
                </div>
                <div class="col-md-4">
                <div class="gallery-item">
                    <img src="image/b2.jpg" alt="Gallery Image 3">
                    <div class="gallery-caption">Image 3</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2024 Hospital. All rights reserved.</p>
                </div>
                <div class="col-md-6">
                    <ul class="footer-icons">
                        <li><a href="#"><i class="bi bi-facebook"></i></a></li>
                        <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                        <li><a href="#"><i class="bi bi-instagram"></i></a></li>
                        <li><a href="#"><i class="bi bi-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <!-- Slideshow Script -->
    <script>
        var slideIndex = 0;
        showSlides();

        function showSlides() {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.opacity = "0";
            }
            slideIndex++;
            if (slideIndex > slides.length) {slideIndex = 1}
            slides[slideIndex-1].style.opacity = "1";
            setTimeout(showSlides, 5000); // Change image every 5 seconds
        }
    </script>
</body>
</html>
