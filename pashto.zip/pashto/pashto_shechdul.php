<!DOCTYPE html>
<html lang="ps" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            overflow: hidden;
            background-color: #333;
            padding: 14px 0;
        }
        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
        .container {
            width: 90%;
            margin: 20px auto;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .form-container input[type="text"], 
        .form-container input[type="time"], 
        .form-container input[type="date"], 
        .form-container select {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container label {
            display: block;
            margin: 10px 0;
        }
        .form-container .form-footer {
            text-align: right;
        }
        .form-container input[type="submit"] {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-container input[type="submit"]:hover {
            background-color: #555;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
        }
        .checkbox-group label {
            margin: 0 10px;
            display: flex;
            align-items: center;
        }
        .checkbox-group input[type="checkbox"] {
            margin: 0 5px 0 0;
        }
        .no-records {
            text-align: center;
            padding: 20px;
            color: #888;
        }
        /* Popup CSS */
        .popup {
            display: none;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1;
        }
        .popup-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="#home">عمومی صفحه</a>
    <a href="book.php">کتابونه</a>
    <a href="logout.php">انګلیسی</a>
    <a href="logout.php">دری</a>
    <a href="logout.php">وتل</a>
</div>

<div class="container">
    <div class="form-container">
        <form method="POST" action="">
            <input type="text" name="name" placeholder="نوم" required>
            <input type="text" name="book_name" placeholder="کتاب نوم" >
            <input type="text" name="class" placeholder="صنف" required>
            <input type="time" name="start_time" placeholder="شروع وخت" required>
            <input type="time" name="end_time" placeholder="ختم وخت" required>
            <input type="date" name="date" placeholder="نیټه" required>
            <label for="computer_use">کمپیو ټر استعمال</label>
            <select name="computer_use" id="computer_use">
                <option value="1">هو</option>
                <option value="0">نه</option>
            </select>
            <label for="internet">انترنت استعمال  </label>
            <select name="internet" id="internet">
                <option value="1">هو</option>
                <option value="0">نه</option>
            </select>
            <div class="form-footer">
                <input type="submit" value="استعمال وونکی ازافه کول">
            </div>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th><input type="checkbox" id="select-all-rows"></th>
                <th>آډی</th>
                <th>نوم</th>
                <th>کتاب نوم</th>
                <th>صنف</th>
                <th>شروع وخت</th>
                <th>ختم وخت</th>
                <th>نیټه</th>
                <th>کمپیو استعمال</th>
                <th>انترنت</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dynamic content will be added here -->
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "library";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Insert data
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $name = $_POST['name'];
                $book_name = $_POST['book_name'];
                $class = $_POST['class'];
                $start_time = $_POST['start_time'];
                $end_time = $_POST['end_time'];
                $date = $_POST['date'];
                $computer_use = $_POST['computer_use'];
                $internet = $_POST['internet'];

                $sql = "INSERT INTO schedule (name, book_name, class, start_time, end_time, date, computer_use, internet) 
                        VALUES ('$name', '$book_name', '$class', '$start_time', '$end_time', '$date', '$computer_use', '$internet')";

                if ($conn->query($sql) === TRUE) {
                    echo "New record created successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }

            // Fetch data to display in descending order by ID
            $sql = "SELECT * FROM schedule ORDER BY id DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td><input type='checkbox' class='row-checkbox'></td>
                            <td>" . $row["id"] . "</td>
                            <td>" . $row["name"] . "</td>
                            <td>" . $row["book_name"] . "</td>
                            <td>" . $row["class"] . "</td>
                            <td>" . $row["start_time"] . "</td>
                            <td>" . $row["end_time"] . "</td>
                            <td>" . $row["date"] . "</td>
                            <td>" . ($row["computer_use"] ? 'Yes' : 'No') . "</td>
                            <td>" . ($row["internet"] ? 'Yes' : 'No') . "</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='10' class='no-records'>No records found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</div>

<!-- Popup HTML -->
<div id="popup" class="popup">
    <div class="popup-content">
        <span class="close">&times;</span>
        <div id="popup-content-text"></div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const selectAllCheckbox = document.getElementById('select-all-rows');
        const rowCheckboxes = document.querySelectorAll('.row-checkbox');
        const popup = document.getElementById('popup');
        const popupContent = document.getElementById('popup-content-text');
        const popupCloseBtn = document.querySelector('.close');

        // Function to handle checkbox select all functionality
        selectAllCheckbox.addEventListener('change', function() {
            rowCheckboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });

        // Function to handle row checkbox change
        rowCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                // If any row is unchecked, uncheck the select all checkbox
                if (!this.checked) {
                    selectAllCheckbox.checked = false;
                }
            });
        });

        // Function to show popup when a row is selected
        rowCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    const row = this.parentElement.parentElement;
                    const rowData = Array.from(row.children).map(cell => cell.textContent);
                    popupContent.innerHTML = `<strong>نوم:</strong> ${rowData[2]}<br>
                                              <strong>کتاب نوم:</strong> ${rowData[3]}<br>
                                              <strong>شروع وخت:</strong> ${rowData[5]}<br>
                                              <strong>ختم وخت:</strong> ${rowData[6]}`;
                    popup.style.display = 'block';
                }
            });
        });

        // Close popup when close button is clicked
        popupCloseBtn.addEventListener('click', function() {
            popup.style.display = 'none';
        });

        // Close popup when clicking outside the popup
        window.addEventListener('click', function(event) {
            if (event.target === popup) {
                popup.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>
