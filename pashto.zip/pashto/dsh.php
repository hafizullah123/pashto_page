<?php
include 'connection.php';

// Fetch the counts for books, papers, users, and labor
$book_count_query = "SELECT COUNT(*) AS count FROM books";
$paper_count_query = "SELECT COUNT(*) AS count FROM research_papers";
$user_count_query = "SELECT COUNT(*) AS count FROM users";
$labor_count_query = "SELECT COUNT(*) AS count FROM users";  // Ensure the table name is correct

$book_count_result = $conn->query($book_count_query);
$paper_count_result = $conn->query($paper_count_query);
$user_count_result = $conn->query($user_count_query);
$labor_count_result = $conn->query($labor_count_query);

if (!$book_count_result || !$paper_count_result || !$user_count_result || !$labor_count_result) {
    die("Error executing query: " . $conn->error);
}

$book_count = $book_count_result->fetch_assoc()['count'];
$paper_count = $paper_count_result->fetch_assoc()['count'];
$user_count = $user_count_result->fetch_assoc()['count'];
$labor_count = $labor_count_result->fetch_assoc()['count'];

// Fetch book genres and their counts
$genres_query = "
    SELECT genres.id, genres.name, COUNT(books.book_id) AS book_count 
    FROM genres 
    LEFT JOIN books ON genres.id = books.genre_id 
    GROUP BY genres.id, genres.name";
$genres_result = $conn->query($genres_query);

if (!$genres_result) {
    die("Error executing genres query: " . $conn->error);
}

$genres = [];
if ($genres_result->num_rows > 0) {
    while ($row = $genres_result->fetch_assoc()) {
        $genres[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .card {
            margin: 10px;
            padding: 20px;
            text-align: center;
        }
        .icon {
            font-size: 50px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Admin Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="booksDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Books <i class="fas fa-book"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="booksDropdown">
                    <a class="dropdown-item" href="view.php">View Books</a>
                    <a class="dropdown-item" href="add_book.php">Add Book</a>
                    <a class="dropdown-item" href="update.php">Manage</a>
                    <div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Genres</h6>
                    <?php foreach ($genres as $genre): ?>
                        <a class="dropdown-item" href="view_genre.php?genre_id=<?php echo $genre['id']; ?>">
                            <i class="fas fa-book-open"></i> <?php echo $genre['name']; ?> 
                            <span class="badge badge-secondary"><?php echo $genre['book_count']; ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="papersDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Papers <i class="fas fa-file-alt"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="papersDropdown">
                    <a class="dropdown-item" href="view1.php">View Papers</a>
                    <a class="dropdown-item" href="add_paper.php">Add Paper</a>
                    <a class="dropdown-item" href="update1.php">Manage</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="usersDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Users <i class="fas fa-users"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="usersDropdown">
                    <a class="dropdown-item" href="#">View Users</a>
                    <a class="dropdown-item" href="#">Add User</a>
                    <a class="dropdown-item" href="#">Manage</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="laborDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Labor <i class="fas fa-tools"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="laborDropdown">
                    <a class="dropdown-item" href="#">View Labor</a>
                    <a class="dropdown-item" href="#">Add Labor</a>
                    <a class="dropdown-item" href="#">Manage</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Logs <i class="fas fa-tools"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Change Password</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container-fluid mt-5">
    <div class="row justify-content-center">
        <div class="col-md-2">
            <div class="card">
                <i class="fas fa-book icon"></i>
                <h3>Books</h3>
                <p><?php echo $book_count; ?></p>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <i class="fas fa-file-alt icon"></i>
                <h3>Papers</h3>
                <p><?php echo $paper_count; ?></p>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <i class="fas fa-users icon
                "></i>
                <h3>Users</h3>
                <p><?php echo $user_count; ?></p>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <i class="fas fa-tools icon"></i>
                <h3>Labor</h3>
                <p><?php echo $labor_count; ?></p>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <?php foreach ($genres as $genre): ?>
            <div class="col-md-2">
                <div class="card">
                    <i class="fas fa-book-open icon"></i>
                    <h3><?php echo $genre['name']; ?></h3>
                    <p><?php echo $genre['book_count']; ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<!-- Bootstrap and custom scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
