<?php
// Default language is English
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

// Function to translate based on current language
function translate($key) {
    global $lang;
    $translations = array();

    // Include the appropriate translation file based on the language
    switch ($lang) {
        case 'ps':
            $translations = array(
                'page_title' => 'د کتابتون مهالویش مدیریت',
                'name' => 'نوم',
                'book_name' => 'د کتاب نوم',
                'class' => 'صنف',
                'start_time' => 'د پیل وخت',
                'end_time' => 'د پای وخت',
                'date' => 'نیټه',
                'computer_use' => 'د کمپیوټر استعمال',
                'internet' => 'انټرنیټ',
                'yes' => 'هو',
                'no' => 'نه',
                'submit' => 'جمع کول',
                'update' => 'تازه کول',
                'actions' => 'اقدامات',
                'edit' => 'سمول',
                'delete' => 'ړنګول',
                'search' => 'لټون',
                'search_button' => 'لټون',
                'no_records' => 'هیڅ ریکارډ ونه موندل شو.',
                'record_created_successfully' => 'ریکارډ په بریالیتوب سره جوړ شو.',
                'record_updated_successfully' => 'ریکارډ په بریالیتوب سره تازه شو.',
                'record_deleted_successfully' => 'ریکارډ په بریالیتوب سره ړنګ شو.',
                'confirm_delete' => 'ایا تاسو ډاډه یاست چې دا ریکارډ ړنګ کړئ؟'
            );
            break;
        case 'fa':
            $translations = array(
                'page_title' => 'مدیریت زمانبندی کتابخانه',
                'name' => 'نام',
                'book_name' => 'نام کتاب',
                'class' => 'صنف',
                'start_time' => 'زمان شروع',
                'end_time' => 'زمان پایان',
                'date' => 'تاریخ',
                'computer_use' => 'استفاده از کامپیوتر',
                'internet' => 'انترنت',
                'yes' => 'بلی',
                'no' => 'خیر',
                'submit' => 'ارسال',
                'update' => 'تازه کردن',
                'actions' => 'اقدامات',
                'edit' => 'ویرایش',
                'delete' => 'حذف',
                'search' => 'جستجو',
                'search_button' => 'جستجو',
                'no_records' => 'هیچ ریکاردی یافت نشد.',
                'record_created_successfully' => 'ریکارد با موفقیت ایجاد شد.',
                'record_updated_successfully' => 'ریکارد با موفقیت تازه شد.',
                'record_deleted_successfully' => 'ریکارد با موفقیت حذف شد.',
                'confirm_delete' => 'آیا مطمئن هستید که می‌خواهید این ریکارد را حذف کنید؟'
            );
            break;
        default:
            $translations = array(
                'page_title' => 'Library Schedule Management',
                'name' => 'Name',
                'book_name' => 'Book Name',
                'class' => 'Class',
                'start_time' => 'Start Time',
                'end_time' => 'End Time',
                'date' => 'Date',
                'computer_use' => 'Computer Use',
                'internet' => 'Internet',
                'yes' => 'Yes',
                'no' => 'No',
                'submit' => 'Submit',
                'update' => 'Update',
                'actions' => 'Actions',
                'edit' => 'Edit',
                'delete' => 'Delete',
                'search' => 'Search',
                'search_button' => 'Search',
                'no_records' => 'No records found.',
                'record_created_successfully' => 'Record created successfully.',
                'record_updated_successfully' => 'Record updated successfully.',
                'record_deleted_successfully' => 'Record deleted successfully.',
                'confirm_delete' => 'Are you sure you want to delete this record?'
            );
            break;
    }

    // Return the translated text if available, or fallback to English
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert or Update data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $book_name = $_POST['book_name'];
    $class = $_POST['class'];
    $start_time = isset($_POST['start_time']) ? $_POST['start_time'] : '';
    $end_time = isset($_POST['end_time']) ? $_POST['end_time'] : '';
    $date = $_POST['date'];
    $computer_use = $_POST['computer_use'];
    $internet = $_POST['internet'];
    $id = isset($_POST['id']) ? $_POST['id'] : '';

    // Check if all required fields are filled
    if (!empty($name) && !empty($book_name) && !empty($class) && !empty($start_time) && !empty($end_time) && !empty($date) && isset($computer_use) && isset($internet)) {
        if (!empty($id)) {
            // Update record
            $sql = "UPDATE schedule SET name=?, book_name=?, class=?, start_time=?, end_time=?, date=?, computer_use=?, internet=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssiii", $name, $book_name, $class, $start_time, $end_time, $date, $computer_use, $internet, $id);

            if ($stmt->execute()) {
                echo translate('record_updated_successfully');
            } else {
                echo "Error: " . $sql . "<br>" . $stmt->error;
            }
        } else {
            // Insert new record
            $sql = "INSERT INTO schedule (name, book_name, class, start_time, end_time, date, computer_use, internet) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssii", $name, $book_name, $class, $start_time, $end_time, $date, $computer_use, $internet);

            if ($stmt->execute()) {
                echo translate('record_created_successfully');
            } else {
                echo "Error: " . $sql . "<br>" . $stmt->error;
            }
        }
    } else {
        echo "All fields are required.";
    }
}

// Fetch data to display in descending order by ID
$sql = "SELECT * FROM schedule ORDER BY id DESC";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $sql = "SELECT * FROM schedule WHERE name LIKE '%$search%' OR book_name LIKE '%$search%' OR class LIKE '%$search%' ORDER BY id DESC";
}
$result = $conn->query($sql);

// Delete record
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM schedule WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo translate('record_deleted_successfully');
    } else {
        echo "Error: " . $sql . "<br>" . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo translate('page_title'); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            direction: <?php echo ($lang == 'ps' || $lang == 'fa') ? 'rtl' : 'ltr'; ?>;
        }
        .navbar {
            overflow: hidden;
            background-color: #333;
            padding: 14px 0;
            direction: ltr; /* Ensure navbar text direction is always LTR */
        }
        .navbar a {
            float: <?php echo ($lang == 'ps' || $lang == 'fa') ? 'right' : 'left'; ?>;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"],
        select {
            width: calc(50% - 10px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            display: inline-block;
        }
        input[type="submit"],
        input[type="button"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: inline-block;
        }
        input[type="button"] {
            background-color: #f44336;
        }
        .form-group {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="?lang=en">English</a>
        <a href="?lang=ps">پښتو</a>
        <a href="?lang=fa">فارسی</a>
    </div>

    <div class="container">
        <h1><?php echo translate('page_title'); ?></h1>

        <form action="" method="POST">
            <input type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
            <div class="form-group">
                <label for="name"><?php echo translate('name'); ?></label>
                <input type="text" name="name" id="name" value="<?php echo isset($edit_row['name']) ? $edit_row['name'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="book_name"><?php echo translate('book_name'); ?></label>
                <input type="text" name="book_name" id="book_name" value="<?php echo isset($edit_row['book_name']) ? $edit_row['book_name'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="class"><?php echo translate('class'); ?></label>
                <input type="text" name="class" id="class" value="<?php echo isset($edit_row['class']) ? $edit_row['class'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="start_time"><?php echo translate('start_time'); ?></label>
                <input type="time" name="start_time" id="start_time" value="<?php echo isset($edit_row['start_time']) ? $edit_row['start_time'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="end_time"><?php echo translate('end_time'); ?></label>
                <input type="time" name="end_time" id="end_time" value="<?php echo isset($edit_row['end_time']) ? $edit_row['end_time'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="date"><?php echo translate('date'); ?></label>
                <input type="date" name="date" id="date" value="<?php echo isset($edit_row['date']) ? $edit_row['date'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="computer_use"><?php echo translate('computer_use'); ?></label>
                <select name="computer_use" id="computer_use" required>
                    <option value="1" <?php echo (isset($edit_row['computer_use']) && $edit_row['computer_use'] == 1) ? 'selected' : ''; ?>><?php echo translate('yes'); ?></option>
                    <option value="0" <?php echo (isset($edit_row['computer_use']) && $edit_row['computer_use'] == 0) ? 'selected' : ''; ?>><?php echo translate('no'); ?></option>
                </select>
            </div>
            <div class="form-group">
                <label for="internet"><?php echo translate('internet'); ?></label>
                <select name="internet" id="internet" required>
                    <option value="1" <?php echo (isset($edit_row['internet']) && $edit_row['internet'] == 1) ? 'selected' : ''; ?>><?php echo translate('yes'); ?></option>
                    <option value="0" <?php echo (isset($edit_row['internet']) && $edit_row['internet'] == 0) ? 'selected' : ''; ?>><?php echo translate('no'); ?></option>
                </select>
            </div>
            <div class="form-group">
                <?php if (isset($_GET['edit'])) { ?>
                    <input type="submit" value="<?php echo translate('update'); ?>">
                <?php } else { ?>
                    <input type="submit" value="<?php echo translate('submit'); ?>">
                <?php } ?>
            </div>
        </form>

        <form action="" method="GET">
            <div class="form-group">
                <input type="text" name="search" placeholder="<?php echo translate('search'); ?>">
                <input type="submit" value="<?php echo translate('search_button'); ?>">
            </div>
        </form>

        <?php if ($result->num_rows > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th><?php echo translate('name'); ?></th>
                        <th><?php echo translate('book_name'); ?></th>
                        <th><?php echo translate('class'); ?></th>
                        <th><?php echo translate('start_time'); ?></th>
                        <th><?php echo translate('end_time'); ?></th>
                        <th><?php echo translate('date'); ?></th>
                        <th><?php echo translate('computer_use'); ?></th>
                        <th><?php echo translate('internet'); ?></th>
                        <th><?php echo translate('actions'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['book_name']; ?></td>
                            <td><?php echo $row['class']; ?></td>
                            <td><?php echo $row['start_time']; ?></td>
                            <td><?php echo $row['end_time']; ?></td>
                            <td><?php echo $row['date']; ?></td>
                            <td><?php echo $row['computer_use'] ? translate('yes') : translate('no'); ?></td>
                            <td><?php echo $row['internet'] ? translate('yes') : translate('no'); ?></td>
                            <td>
                                <a href="?edit=<?php echo $row['id']; ?>&lang=<?php echo $lang; ?>"><?php echo translate('edit'); ?></a> |
                                <a href="?delete=<?php echo $row['id']; ?>&lang=<?php echo $lang; ?>" onclick="return confirm('<?php echo translate('confirm_delete'); ?>');"><?php echo translate('delete'); ?></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p><?php echo translate('no_records'); ?></p>
        <?php } ?>
    </div>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
